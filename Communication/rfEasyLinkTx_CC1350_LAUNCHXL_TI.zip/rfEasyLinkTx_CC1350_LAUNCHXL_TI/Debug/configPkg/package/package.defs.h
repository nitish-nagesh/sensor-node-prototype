/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B06
 */

#ifndef configPkg__
#define configPkg__



#endif /* configPkg__ */ 
